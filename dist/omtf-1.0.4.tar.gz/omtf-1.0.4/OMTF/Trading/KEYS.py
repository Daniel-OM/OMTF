
polygon = 'cUlHULSDVdLm9Up1TsKxF3RU2dEKm3nq'
trade_zero = {'user':'DAL55983', 'pwd':'*Onemade3680'}