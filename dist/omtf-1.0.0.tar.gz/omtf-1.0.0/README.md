# OM Trading Framework

This is a propietary framework for getting trading data, testing and backtesting strategies. The execution implementation is half way there too. Looking to rebuild it for bagging, iceberg and portfolio management.